import { createBrowserRouter } from "react-router";
import Home from "./pages/home";
import Search from "./pages/search";
import Standings from "./pages/standings";
import MatchSheet from "./pages/match-sheet";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/search",
    Component: Search,
  },
  {
    path: "/standings",
    Component: Standings,
  },
  {
    path: "/match/:matchId",
    Component: MatchSheet,
  },
]);
