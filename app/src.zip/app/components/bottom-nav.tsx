import { Home, Search, Calendar, Trophy } from "lucide-react";
import { Link, useLocation } from "react-router";

interface BottomNavProps {
  currentPage: "home" | "search" | "standings";
}

export function BottomNav({ currentPage }: BottomNavProps) {
  const location = useLocation();

  const navItems = [
    { id: "home", label: "Accueil", icon: Home, path: "/" },
    { id: "search", label: "Rechercher", icon: Search, path: "/search" },
    { id: "standings", label: "Classements", icon: Trophy, path: "/standings" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#1f2435] border-t border-gray-800 pb-safe max-w-[390px] mx-auto">
      <div className="flex items-center justify-around px-2 py-2">
        {navItems.map((item) => {
          const isActive = currentPage === item.id;
          const Icon = item.icon;

          return (
            <Link
              key={item.id}
              to={item.path}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? "text-[#4f8ef7]"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <Icon className="w-6 h-6" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}