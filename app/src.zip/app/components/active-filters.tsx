import { X } from "lucide-react";

export interface ActiveFilter {
  type: string;
  label: string;
  value: string;
}

interface ActiveFiltersProps {
  filters: ActiveFilter[];
  onRemoveFilter: (filter: ActiveFilter) => void;
}

export function ActiveFilters({ filters, onRemoveFilter }: ActiveFiltersProps) {
  if (filters.length === 0) return null;

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {filters.map((filter, index) => (
        <button
          key={`${filter.type}-${filter.value}-${index}`}
          onClick={() => onRemoveFilter(filter)}
          className="flex items-center gap-1.5 bg-[#4f8ef7]/20 border border-[#4f8ef7]/40 text-[#4f8ef7] px-3 py-1.5 rounded-full text-sm font-medium hover:bg-[#4f8ef7]/30 transition-colors"
        >
          {filter.label}
          <X className="w-3.5 h-3.5" />
        </button>
      ))}
    </div>
  );
}