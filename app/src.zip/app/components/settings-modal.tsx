import { X, ChevronDown } from "lucide-react";
import { useState, useEffect } from "react";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  league: string;
  followedTeams: Array<{ sport: string; category: string; team: string }>;
  onLeagueChange: (league: string) => void;
  onFollowedTeamsChange: (teams: Array<{ sport: string; category: string; team: string }>) => void;
}

export function SettingsModal({
  isOpen,
  onClose,
  league,
  followedTeams,
  onLeagueChange,
  onFollowedTeamsChange,
}: SettingsModalProps) {
  const [selectedLeague, setSelectedLeague] = useState(league);
  const [selectedSport, setSelectedSport] = useState("Basket");
  const [selectedCategory, setSelectedCategory] = useState("Masculin");
  const [selectedTeam, setSelectedTeam] = useState("");
  const [tempFollowedTeams, setTempFollowedTeams] = useState(followedTeams);
  const [leagueOpen, setLeagueOpen] = useState(false);
  const [sportOpen, setSportOpen] = useState(false);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [teamOpen, setTeamOpen] = useState(false);

  const leagues = [
    "Pays de la Loire",
    "Auvergne-Rhône-Alpes",
    "Île-de-France",
    "Occitanie",
    "Nouvelle-Aquitaine",
    "Bretagne",
  ];

  const sports = ["Basket", "Volley", "Football", "Rugby", "Handball", "Tennis"];
  const categories = ["Masculin", "Féminin", "Mixte"];
  const teams = [
    "Centrale 1",
    "Centrale 2",
    "IMT Atlantique",
    "Audencia 1",
    "Audencia 2",
    "Audencia 3",
    "NSU",
  ];

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const handleToggleTeam = (team: string) => {
    const existingIndex = tempFollowedTeams.findIndex(
      (t) => t.sport === selectedSport && t.category === selectedCategory && t.team === team
    );

    if (existingIndex >= 0) {
      setTempFollowedTeams(tempFollowedTeams.filter((_, i) => i !== existingIndex));
    } else {
      setTempFollowedTeams([
        ...tempFollowedTeams,
        { sport: selectedSport, category: selectedCategory, team },
      ]);
    }
  };

  const isTeamFollowed = (team: string) => {
    return tempFollowedTeams.some(
      (t) => t.sport === selectedSport && t.category === selectedCategory && t.team === team
    );
  };

  const handleSave = () => {
    onLeagueChange(selectedLeague);
    onFollowedTeamsChange(tempFollowedTeams);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 z-50 transition-opacity"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-[#1f2435] rounded-2xl w-[90%] max-w-[350px] max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-700 flex-shrink-0">
          <h2 className="text-lg font-semibold text-white">Paramètres</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-5 py-6">
          {/* League selection */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-3">
              Ligue
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setLeagueOpen(!leagueOpen);
                  setSportOpen(false);
                  setCategoryOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{selectedLeague}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    leagueOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {leagueOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-50">
                  {leagues.map((l) => (
                    <button
                      key={l}
                      onClick={() => {
                        setSelectedLeague(l);
                        setLeagueOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        selectedLeague === l
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Followed teams */}
          <div>
            <label className="block text-sm font-semibold text-gray-300 mb-3">
              Équipes suivies
            </label>

            {/* Sport selector */}
            <div className="mb-3">
              <p className="text-xs text-gray-500 mb-2">Sport</p>
              <div className="relative">
                <button
                  onClick={() => {
                    setSportOpen(!sportOpen);
                    setLeagueOpen(false);
                    setCategoryOpen(false);
                  }}
                  className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
                >
                  <span>{selectedSport}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 transition-transform ${
                      sportOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {sportOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-50">
                    {sports.map((sport) => (
                      <button
                        key={sport}
                        onClick={() => {
                          setSelectedSport(sport);
                          setSportOpen(false);
                        }}
                        className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                          selectedSport === sport
                            ? "bg-[#4f8ef7] text-white"
                            : "text-gray-300 hover:bg-gray-800"
                        }`}
                      >
                        {sport}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Category selector */}
            <div className="mb-3">
              <p className="text-xs text-gray-500 mb-2">Catégorie</p>
              <div className="relative">
                <button
                  onClick={() => {
                    setCategoryOpen(!categoryOpen);
                    setLeagueOpen(false);
                    setSportOpen(false);
                  }}
                  className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
                >
                  <span>{selectedCategory}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 transition-transform ${
                      categoryOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {categoryOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl z-50">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => {
                          setSelectedCategory(cat);
                          setCategoryOpen(false);
                        }}
                        className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                          selectedCategory === cat
                            ? "bg-[#4f8ef7] text-white"
                            : "text-gray-300 hover:bg-gray-800"
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Team selector */}
            <div className="mb-3">
              <p className="text-xs text-gray-500 mb-2">Équipe</p>
              <div className="relative">
                <button
                  onClick={() => {
                    setTeamOpen(!teamOpen);
                    setLeagueOpen(false);
                    setSportOpen(false);
                    setCategoryOpen(false);
                  }}
                  className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
                >
                  <span className={selectedTeam ? "" : "text-gray-500"}>
                    {selectedTeam || "Sélectionner une équipe"}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 transition-transform ${
                      teamOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {teamOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-50">
                    {teams.map((team) => (
                      <button
                        key={team}
                        onClick={() => {
                          handleToggleTeam(team);
                          setSelectedTeam("");
                          setTeamOpen(false);
                        }}
                        className="w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg text-gray-300 hover:bg-gray-800"
                      >
                        {team}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Selected teams list */}
            {tempFollowedTeams.filter(t => t.sport === selectedSport && t.category === selectedCategory).length > 0 && (
              <div className="mt-3 space-y-2">
                {tempFollowedTeams
                  .filter(t => t.sport === selectedSport && t.category === selectedCategory)
                  .map((followedTeam, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between bg-[#4f8ef7] text-white px-4 py-2.5 rounded-lg"
                    >
                      <span>{followedTeam.team}</span>
                      <button
                        onClick={() => handleToggleTeam(followedTeam.team)}
                        className="hover:bg-[#4080d7] rounded p-1 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
              </div>
            )}

            {tempFollowedTeams.length > 0 && (
              <div className="mt-3 text-xs text-gray-500">
                {tempFollowedTeams.length} équipe{tempFollowedTeams.length > 1 ? "s" : ""} suivie{tempFollowedTeams.length > 1 ? "s" : ""}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-gray-700 p-4 flex gap-3 flex-shrink-0">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 bg-gray-700 text-white rounded-lg font-medium hover:bg-gray-600 transition-colors"
          >
            Annuler
          </button>
          <button
            onClick={handleSave}
            className="flex-1 px-4 py-3 bg-[#4f8ef7] text-white rounded-lg font-medium hover:bg-[#4080d7] transition-colors"
          >
            Enregistrer
          </button>
        </div>
      </div>
    </>
  );
}