import { X, ChevronDown } from "lucide-react";
import { useState } from "react";

interface StandingsFilterSheetProps {
  isOpen: boolean;
  onClose: () => void;
  sportFilter: string;
  categoryFilter: string;
  championshipFilter: string;
  pouleFilter: string;
  onSportChange: (sport: string) => void;
  onCategoryChange: (category: string) => void;
  onChampionshipChange: (championship: string) => void;
  onPouleChange: (poule: string) => void;
  onApply: () => void;
  onClear: () => void;
}

export function StandingsFilterSheet({
  isOpen,
  onClose,
  sportFilter,
  categoryFilter,
  championshipFilter,
  pouleFilter,
  onSportChange,
  onCategoryChange,
  onChampionshipChange,
  onPouleChange,
  onApply,
  onClear,
}: StandingsFilterSheetProps) {
  const [sportOpen, setSportOpen] = useState(false);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [championshipOpen, setChampionshipOpen] = useState(false);
  const [pouleOpen, setPouleOpen] = useState(false);

  const sportFilters = [
    { value: "Tous", label: "Tous les sports" },
    { value: "Basket", label: "Basketball" },
    { value: "Volley", label: "Volleyball" },
    { value: "Football", label: "Football" },
    { value: "Rugby", label: "Rugby" },
    { value: "Handball", label: "Handball" },
    { value: "Tennis", label: "Tennis" },
  ];

  const categoryFilters = [
    { value: "Tous", label: "Tous" },
    { value: "Masculin", label: "Masculin" },
    { value: "Féminin", label: "Féminin" },
    { value: "Mixte", label: "Mixte" },
  ];

  const championshipFilters = ["District", "Écoles"];

  const getPouleFilters = () => {
    if (championshipFilter === "District") {
      return ["Poule 1", "Poule 2", "Poule 3"];
    } else if (championshipFilter === "Écoles") {
      return ["Poule 1", "Poule 2"];
    }
    return ["Poule 1"];
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Bottom Sheet */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#1f2435] rounded-t-3xl z-50 max-w-[390px] mx-auto max-h-[85vh] flex flex-col animate-slide-up">
        {/* Handle bar */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-10 h-1 bg-gray-600 rounded-full"></div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-gray-700 flex-shrink-0">
          <h2 className="text-lg font-semibold text-white">Filtres</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto px-5 py-6">
          {/* Sport dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Sport
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setSportOpen(!sportOpen);
                  setCategoryOpen(false);
                  setChampionshipOpen(false);
                  setPouleOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>
                  {sportFilters.find((filter) => filter.value === sportFilter)?.label
                    || "Tous les sports"}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    sportOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {sportOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl z-50">
                  {sportFilters.map((filter) => (
                    <button
                      key={filter.value}
                      onClick={() => {
                        onSportChange(filter.value);
                        setSportOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        sportFilter === filter.value
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Category dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Catégorie
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setCategoryOpen(!categoryOpen);
                  setSportOpen(false);
                  setChampionshipOpen(false);
                  setPouleOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>
                  {categoryFilters.find((filter) => filter.value === categoryFilter)?.label
                    || "Tous"}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    categoryOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {categoryOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl z-50">
                  {categoryFilters.map((filter) => (
                    <button
                      key={filter.value}
                      onClick={() => {
                        onCategoryChange(filter.value);
                        setCategoryOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        categoryFilter === filter.value
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Championship dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Championnat
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setChampionshipOpen(!championshipOpen);
                  setSportOpen(false);
                  setCategoryOpen(false);
                  setPouleOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{championshipFilter}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    championshipOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {championshipOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl z-50">
                  {championshipFilters.map((filter) => (
                    <button
                      key={filter}
                      onClick={() => {
                        onChampionshipChange(filter);
                        setChampionshipOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        championshipFilter === filter
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Poule dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Poule
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setPouleOpen(!pouleOpen);
                  setSportOpen(false);
                  setCategoryOpen(false);
                  setChampionshipOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{pouleFilter}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    pouleOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {pouleOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl z-50">
                  {getPouleFilters().map((filter) => (
                    <button
                      key={filter}
                      onClick={() => {
                        onPouleChange(filter);
                        setPouleOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        pouleFilter === filter
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer buttons */}
        <div className="border-t border-gray-700 px-5 py-4 flex gap-3 flex-shrink-0">
          <button
            onClick={() => {
              onClear();
              onClose();
            }}
            className="flex-1 px-4 py-3 bg-gray-700 text-white rounded-lg font-medium hover:bg-gray-600 transition-colors"
          >
            Réinitialiser
          </button>
          <button
            onClick={() => {
              onApply();
              onClose();
            }}
            className="flex-1 px-4 py-3 bg-[#4f8ef7] text-white rounded-lg font-medium hover:bg-[#4080d7] transition-colors"
          >
            Appliquer
          </button>
        </div>
      </div>
    </>
  );
}