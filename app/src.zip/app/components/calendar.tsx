import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

interface CalendarProps {
  selectedDate: Date | null;
  onDateChange: (date: Date | null) => void;
}

export function Calendar({ selectedDate, onDateChange }: CalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const monthNames = [
    "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
    "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
  ];

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    return { daysInMonth, startingDayOfWeek };
  };

  const { daysInMonth, startingDayOfWeek } = getDaysInMonth(currentMonth);

  const goToPreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const goToNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const handleDayClick = (day: number) => {
    const clickedDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    
    // Si la date est déjà sélectionnée, la désélectionner
    if (selectedDate && 
        selectedDate.getDate() === day && 
        selectedDate.getMonth() === currentMonth.getMonth() &&
        selectedDate.getFullYear() === currentMonth.getFullYear()) {
      onDateChange(null);
    } else {
      onDateChange(clickedDate);
    }
  };

  const isDateSelected = (day: number) => {
    if (!selectedDate) return false;
    return selectedDate.getDate() === day &&
           selectedDate.getMonth() === currentMonth.getMonth() &&
           selectedDate.getFullYear() === currentMonth.getFullYear();
  };

  const isToday = (day: number) => {
    const today = new Date();
    return today.getDate() === day &&
           today.getMonth() === currentMonth.getMonth() &&
           today.getFullYear() === currentMonth.getFullYear();
  };

  // Générer les jours du calendrier
  const days = [];
  
  // Jours vides avant le début du mois (dimanche = 0, lundi = 1, etc.)
  const adjustedStartDay = startingDayOfWeek === 0 ? 6 : startingDayOfWeek - 1;
  for (let i = 0; i < adjustedStartDay; i++) {
    days.push(<div key={`empty-${i}`} className="h-9" />);
  }

  // Jours du mois
  for (let day = 1; day <= daysInMonth; day++) {
    const selected = isDateSelected(day);
    const today = isToday(day);
    
    days.push(
      <button
        key={day}
        onClick={() => handleDayClick(day)}
        className={`h-9 rounded-lg text-sm font-medium transition-colors ${
          selected
            ? "bg-[#4f8ef7] text-white"
            : today
            ? "bg-[#4f8ef7]/20 text-[#4f8ef7]"
            : "text-gray-300 hover:bg-gray-700"
        }`}
      >
        {day}
      </button>
    );
  }

  return (
    <div className="bg-[#1a1d2e] rounded-lg p-4">
      {/* En-tête avec navigation */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={goToPreviousMonth}
          className="p-1 hover:bg-gray-700 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-5 h-5 text-gray-400" />
        </button>
        
        <div className="text-white font-semibold">
          {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
        </div>
        
        <button
          onClick={goToNextMonth}
          className="p-1 hover:bg-gray-700 rounded-lg transition-colors"
        >
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* Jours de la semaine */}
      <div className="grid grid-cols-7 gap-1 mb-2">
        {["L", "M", "M", "J", "V", "S", "D"].map((day, i) => (
          <div key={i} className="h-9 flex items-center justify-center text-xs text-gray-500 font-medium">
            {day}
          </div>
        ))}
      </div>

      {/* Grille de jours */}
      <div className="grid grid-cols-7 gap-1">
        {days}
      </div>

      {/* Bouton pour effacer la sélection */}
      {selectedDate && (
        <button
          onClick={() => onDateChange(null)}
          className="w-full mt-3 py-2 text-sm text-gray-400 hover:text-white transition-colors"
        >
          Effacer la sélection
        </button>
      )}
    </div>
  );
}