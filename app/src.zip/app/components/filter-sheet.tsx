import { X, ChevronDown } from "lucide-react";
import { useEffect, useState } from "react";
import { Calendar } from "./calendar";

interface FilterSheetProps {
  isOpen: boolean;
  onClose: () => void;
  sportFilter: string;
  genderFilter: string;
  teamFilters: string[];
  championshipFilter: string;
  pouleFilter: string;
  selectedDate: Date | null;
  statusFilter: string;
  onSportChange: (sport: string) => void;
  onGenderChange: (gender: string) => void;
  onTeamFiltersChange: (teams: string[]) => void;
  onChampionshipChange: (championship: string) => void;
  onPouleChange: (poule: string) => void;
  onDateChange: (date: Date | null) => void;
  onStatusChange: (status: string) => void;
  onApply: () => void;
  onClear: () => void;
  activeCount: number;
}

export function FilterSheet({
  isOpen,
  onClose,
  sportFilter,
  genderFilter,
  teamFilters,
  championshipFilter,
  pouleFilter,
  selectedDate,
  statusFilter,
  onSportChange,
  onGenderChange,
  onTeamFiltersChange,
  onChampionshipChange,
  onPouleChange,
  onDateChange,
  onStatusChange,
  onApply,
  onClear,
  activeCount,
}: FilterSheetProps) {
  const [sportOpen, setSportOpen] = useState(false);
  const [genderOpen, setGenderOpen] = useState(false);
  const [teamOpen, setTeamOpen] = useState(false);
  const [championshipOpen, setChampionshipOpen] = useState(false);
  const [pouleOpen, setPouleOpen] = useState(false);
  const [dateOpen, setDateOpen] = useState(false);
  const [statusOpen, setStatusOpen] = useState(false);

  const sportFilters = [
    { value: "Tous", label: "Tous les sports" },
    { value: "Basket", label: "Basketball" },
    { value: "Volley", label: "Volleyball" },
    { value: "Football", label: "Football" },
    { value: "Rugby", label: "Rugby" },
    { value: "Handball", label: "Handball" },
    { value: "Tennis", label: "Tennis" },
  ];

  const genderFilters = [
    { value: "Tous", label: "Tous" },
    { value: "M", label: "Masculin" },
    { value: "F", label: "Féminin" },
    { value: "Mixte", label: "Mixte" },
  ];

  const availableTeams = [
    "Centrale 1",
    "Centrale 2",
    "IMT Atlantique",
    "Audencia 1",
    "Audencia 2",
    "Audencia 3",
    "NSU",
  ];

  const championshipFilters = [
    { value: "Tous", label: "Tous" },
    { value: "District", label: "District" },
    { value: "Écoles", label: "Écoles" },
  ];

  const getPouleFilters = () => {
    if (championshipFilter === "District") {
      return [
        { value: "Toutes", label: "Toutes" },
        { value: "Poule 1", label: "Poule 1" },
        { value: "Poule 2", label: "Poule 2" },
        { value: "Poule 3", label: "Poule 3" },
      ];
    } else if (championshipFilter === "Écoles") {
      return [
        { value: "Toutes", label: "Toutes" },
        { value: "Poule 1", label: "Poule 1" },
        { value: "Poule 2", label: "Poule 2" },
      ];
    }
    return [{ value: "Toutes", label: "Toutes" }];
  };

  const handleTeamToggle = (team: string) => {
    if (teamFilters.includes(team)) {
      onTeamFiltersChange(teamFilters.filter((t) => t !== team));
    } else {
      onTeamFiltersChange([...teamFilters, team]);
    }
  };

  // Prevent body scroll when sheet is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  // Close dropdowns when sheet closes
  useEffect(() => {
    if (!isOpen) {
      setSportOpen(false);
      setGenderOpen(false);
      setTeamOpen(false);
      setChampionshipOpen(false);
      setPouleOpen(false);
      setDateOpen(false);
      setStatusOpen(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const getSportLabel = () => {
    const selected = sportFilters.find((f) => f.value === sportFilter);
    return selected?.label || "Tous les sports";
  };

  const getGenderLabel = () => {
    const selected = genderFilters.find((f) => f.value === genderFilter);
    return selected?.label || "Tous";
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Bottom sheet - 5/6 of screen height */}
      <div className="fixed left-0 right-0 bottom-0 z-50 bg-[#1f2435] rounded-t-2xl flex flex-col animate-slide-up max-w-[390px] mx-auto" style={{ height: 'calc(100vh * 5 / 6)', maxHeight: '703px' }}>
        {/* Handle bar */}
        <div className="flex justify-center py-3 flex-shrink-0">
          <div className="w-10 h-1 bg-gray-600 rounded-full" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 pb-4 border-b border-gray-700 flex-shrink-0">
          <h2 className="text-lg font-semibold text-white">Filtres</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto px-5 py-6">
          {/* Sport dropdown */}
          <div className="mb-5">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Sport
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setSportOpen(!sportOpen);
                  setGenderOpen(false);
                  setTeamOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{getSportLabel()}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    sportOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown menu - opens downward */}
              {sportOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-10">
                  {sportFilters.map((filter) => (
                    <button
                      key={filter.value}
                      onClick={() => {
                        onSportChange(filter.value);
                        setSportOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        sportFilter === filter.value
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Gender dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Catégorie
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setGenderOpen(!genderOpen);
                  setSportOpen(false);
                  setTeamOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{getGenderLabel()}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    genderOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown menu - opens downward */}
              {genderOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-10">
                  {genderFilters.map((filter) => (
                    <button
                      key={filter.value}
                      onClick={() => {
                        onGenderChange(filter.value);
                        setGenderOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        genderFilter === filter.value
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Team filters */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Équipes
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setTeamOpen(!teamOpen);
                  setSportOpen(false);
                  setGenderOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{teamFilters.length > 0 ? `${teamFilters.length} sélectionnées` : "Toutes"}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    teamOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown menu - opens downward */}
              {teamOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-10">
                  {availableTeams.map((team) => (
                    <button
                      key={team}
                      onClick={() => handleTeamToggle(team)}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        teamFilters.includes(team)
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {team}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Championship dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Championnat
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setChampionshipOpen(!championshipOpen);
                  setSportOpen(false);
                  setGenderOpen(false);
                  setTeamOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{championshipFilter}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    championshipOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown menu - opens downward */}
              {championshipOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-10">
                  {championshipFilters.map((filter) => (
                    <button
                      key={filter.value}
                      onClick={() => {
                        onChampionshipChange(filter.value);
                        setChampionshipOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        championshipFilter === filter.value
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Poule dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Poule
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setPouleOpen(!pouleOpen);
                  setSportOpen(false);
                  setGenderOpen(false);
                  setTeamOpen(false);
                  setChampionshipOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{pouleFilter}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    pouleOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown menu - opens downward */}
              {pouleOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-10">
                  {getPouleFilters().map((filter) => (
                    <button
                      key={filter.value}
                      onClick={() => {
                        onPouleChange(filter.value);
                        setPouleOpen(false);
                      }}
                      className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                        pouleFilter === filter.value
                          ? "bg-[#4f8ef7] text-white"
                          : "text-gray-300 hover:bg-gray-800"
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Date dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Date
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setDateOpen(!dateOpen);
                  setSportOpen(false);
                  setGenderOpen(false);
                  setTeamOpen(false);
                  setChampionshipOpen(false);
                  setPouleOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{selectedDate ? selectedDate.toLocaleDateString() : "Toutes les dates"}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    dateOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown menu - opens downward */}
              {dateOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-10">
                  <Calendar
                    selectedDate={selectedDate}
                    onDateChange={onDateChange}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Status dropdown */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-300 mb-2">
              Statut
            </label>
            <div className="relative">
              <button
                onClick={() => {
                  setStatusOpen(!statusOpen);
                  setSportOpen(false);
                  setGenderOpen(false);
                  setTeamOpen(false);
                  setChampionshipOpen(false);
                  setPouleOpen(false);
                  setDateOpen(false);
                }}
                className="w-full bg-[#0f1117] border border-gray-700 rounded-lg px-4 py-3 text-left text-white flex items-center justify-between hover:border-gray-600 transition-colors min-h-[48px]"
              >
                <span>{statusFilter}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    statusOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown menu - opens downward */}
              {statusOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f1117] border border-gray-700 rounded-lg shadow-2xl max-h-72 overflow-y-auto z-10">
                  <button
                    onClick={() => {
                      onStatusChange("Tous");
                      setStatusOpen(false);
                    }}
                    className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                      statusFilter === "Tous"
                        ? "bg-[#4f8ef7] text-white"
                        : "text-gray-300 hover:bg-gray-800"
                    }`}
                  >
                    Tous
                  </button>
                  <button
                    onClick={() => {
                      onStatusChange("À venir");
                      setStatusOpen(false);
                    }}
                    className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                      statusFilter === "À venir"
                        ? "bg-[#4f8ef7] text-white"
                        : "text-gray-300 hover:bg-gray-800"
                    }`}
                  >
                    À venir
                  </button>
                  <button
                    onClick={() => {
                      onStatusChange("Terminé");
                      setStatusOpen(false);
                    }}
                    className={`w-full px-4 py-3 text-left transition-colors min-h-[48px] first:rounded-t-lg last:rounded-b-lg ${
                      statusFilter === "Terminé"
                        ? "bg-[#4f8ef7] text-white"
                        : "text-gray-300 hover:bg-gray-800"
                    }`}
                  >
                    Terminé
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="border-t border-gray-700 p-4 flex gap-3 flex-shrink-0">
          <button
            onClick={onClear}
            className="flex-1 px-4 py-3 bg-gray-700 text-white rounded-lg font-medium hover:bg-gray-600 transition-colors min-h-[48px]"
          >
            Réinitialiser
          </button>
          <button
            onClick={() => {
              onApply();
              onClose();
            }}
            className="flex-1 px-4 py-3 bg-[#4f8ef7] text-white rounded-lg font-medium hover:bg-[#4080d7] transition-colors min-h-[48px]"
          >
            Appliquer {activeCount > 0 && `(${activeCount})`}
          </button>
        </div>
      </div>
    </>
  );
}