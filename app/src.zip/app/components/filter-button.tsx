import { SlidersHorizontal } from "lucide-react";

interface FilterButtonProps {
  activeCount: number;
  onClick: () => void;
}

export function FilterButton({ activeCount, onClick }: FilterButtonProps) {
  return (
    <button
      onClick={onClick}
      className="relative p-2 hover:bg-gray-800 rounded-lg transition-colors"
    >
      <SlidersHorizontal className="w-5 h-5 text-gray-400" />
      {activeCount > 0 && (
        <span className="absolute -top-1 -right-1 bg-[#4f8ef7] text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
          {activeCount}
        </span>
      )}
    </button>
  );
}
