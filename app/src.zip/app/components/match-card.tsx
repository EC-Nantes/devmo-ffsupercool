import { MapPin } from "lucide-react";
import { useNavigate } from "react-router";

export interface Match {
  id: string;
  sport: string;
  sportIcon: string;
  category: string;
  teamA: string;
  teamB: string;
  date: string;
  time: string;
  venue: string;
  status: "upcoming" | "finished";
  scoreA?: number;
  scoreB?: number;
  sportColor: string;
  championship?: string;
  poule?: string;
}

interface MatchCardProps {
  match: Match;
}

export function MatchCard({ match }: MatchCardProps) {
  const navigate = useNavigate();
  const getStatusBadge = () => {
    if (match.status === "finished") {
      return (
        <div className="text-gray-400 text-sm font-semibold">
          {match.scoreA} – {match.scoreB}
        </div>
      );
    } else {
      return (
        <div className="bg-[#4f8ef7]/20 text-[#4f8ef7] px-2.5 py-1 rounded-full text-xs font-medium">
          À venir
        </div>
      );
    }
  };

  const handleClick = () => {
    if (match.status === "finished") {
      navigate(`/match/${match.id}`);
    }
  };

  return (
    <div
      onClick={handleClick}
      className={`bg-[#1f2435] border border-gray-800 rounded-xl p-4 relative overflow-hidden ${
        match.status === "finished" ? "opacity-60 cursor-pointer hover:opacity-80 hover:border-gray-700" : ""
      } transition-all`}
    >
      {/* Left border accent */}
      <div
        className="absolute left-0 top-0 bottom-0 w-1"
        style={{ backgroundColor: match.sportColor }}
      ></div>

      {/* Sport info */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <span>{match.sportIcon}</span>
          <span>
            {match.sport} · {match.category}
          </span>
        </div>
        {getStatusBadge()}
      </div>

      {/* Teams */}
      <div className="flex items-center justify-center gap-3 mb-3">
        <span className="font-semibold text-white text-lg flex-1 text-right">
          {match.teamA}
        </span>
        <span className="text-gray-500 text-sm font-medium">VS</span>
        <span className="font-semibold text-white text-lg flex-1 text-left">
          {match.teamB}
        </span>
      </div>

      {/* Date and location */}
      <div className="flex items-center justify-between text-xs text-gray-400">
        <span>
          {match.date} · {match.time}
        </span>
        <div className="flex items-center gap-1">
          <MapPin className="w-3.5 h-3.5" />
          <span>{match.venue}</span>
        </div>
      </div>
    </div>
  );
}