import { useState } from "react";
import { Settings, X } from "lucide-react";
import { MatchCard } from "../components/match-card";
import { BottomNav } from "../components/bottom-nav";
import { SettingsModal } from "../components/settings-modal";
import { mockMatches } from "../data/mock-data";

export default function HomePage() {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [league, setLeague] = useState("Pays de la Loire");
  const [followedTeams, setFollowedTeams] = useState<Array<{ sport: string; category: string; team: string }>>([
    { sport: "Basket", category: "Masculin", team: "Centrale 1" },
    { sport: "Volley", category: "Féminin", team: "Audencia 1" },
  ]);

  // Format date for display
  const formatDate = (date: Date) => {
    const days = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
    const months = ['jan', 'fév', 'mar', 'avr', 'mai', 'juin', 'juil', 'août', 'sep', 'oct', 'nov', 'déc'];
    const dayName = days[date.getDay()];
    const day = date.getDate();
    const month = months[date.getMonth()];
    return `${dayName}. ${day} ${month}`;
  };

  const formatTime = (date: Date) => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    return `${hours}h${minutes.toString().padStart(2, '0')}`;
  };

  const getSportIcon = (sport: string) => {
    const icons: Record<string, string> = {
      Basket: "🏀",
      Volley: "🏐",
      Football: "⚽",
      Rugby: "🏉",
      Handball: "🤾",
      Tennis: "🎾",
    };
    return icons[sport] || "⚽";
  };

  const getSportColor = (sport: string) => {
    const colors: Record<string, string> = {
      Basket: "#4f8ef7",
      Volley: "#10b981",
      Football: "#f97316",
      Rugby: "#8b5cf6",
      Handball: "#ec4899",
      Tennis: "#eab308",
    };
    return colors[sport] || "#4f8ef7";
  };

  // Filter matches for followed teams
  const filteredMatches = mockMatches.filter((match) => {
    return followedTeams.some(
      (ft) =>
        ft.sport === match.sport &&
        ft.category === match.category &&
        (ft.team === match.teamA || ft.team === match.teamB)
    );
  });

  // Sort matches by date
  const sortedMatches = [...filteredMatches].sort((a, b) => {
    return a.date.getTime() - b.date.getTime();
  });

  // Convert to match card format
  const matchesForDisplay = sortedMatches.map(match => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const matchDate = new Date(match.date);
    matchDate.setHours(0, 0, 0, 0);
    
    return {
      id: match.id,
      sport: match.sport,
      sportIcon: getSportIcon(match.sport),
      category: match.category,
      teamA: match.teamA,
      teamB: match.teamB,
      date: formatDate(match.date),
      time: formatTime(match.date),
      venue: match.venue,
      status: matchDate < today ? "finished" : "upcoming" as "finished" | "upcoming",
      scoreA: match.scoreA,
      scoreB: match.scoreB,
      sportColor: getSportColor(match.sport),
      championship: match.championship,
      poule: match.poule,
    };
  });

  const finishedMatches = matchesForDisplay.filter(m => m.status === 'finished');
  const upcomingMatches = matchesForDisplay.filter(m => m.status === 'upcoming');

  const handleRemoveTeam = (index: number) => {
    setFollowedTeams(followedTeams.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen bg-[#0f1117] text-white flex flex-col max-w-[390px] mx-auto">
      {/* Fixed header */}
      <div className="flex-shrink-0 px-4 pt-6 pb-4 border-b border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold">Accueil</h1>
            <p className="text-sm text-gray-400 mt-1">{league}</p>
          </div>
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-2.5 bg-[#1f2435] hover:bg-[#2a2f45] rounded-lg transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {followedTeams.length > 0 ? (
          <div className="mt-3 space-y-2">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
              Équipes suivies ({followedTeams.length})
            </div>
            <div className="flex flex-wrap gap-2">
              {followedTeams.map((team, index) => (
                <div
                  key={index}
                  className="bg-[#1f2435] border border-gray-700 rounded-lg px-3 py-2 pr-8 text-xs relative group"
                >
                  <div className="font-medium text-white">{team.team}</div>
                  <div className="text-gray-400 mt-0.5">
                    {team.sport} · {team.category}
                  </div>
                  <button
                    onClick={() => handleRemoveTeam(index)}
                    className="absolute top-1.5 right-1.5 p-1 bg-gray-700 hover:bg-red-500 rounded-full transition-colors opacity-0 group-hover:opacity-100"
                    aria-label="Supprimer l'équipe"
                  >
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-xs text-gray-500">
            Aucune équipe suivie
          </div>
        )}
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto px-4 py-4 pb-24">
        {followedTeams.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-500">
            <Settings className="w-16 h-16 mb-4 opacity-50" />
            <p className="text-lg">Aucune équipe suivie</p>
            <p className="text-sm mt-2 text-center">Configurez vos équipes dans les paramètres</p>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="mt-4 px-4 py-2 bg-[#4f8ef7] text-white rounded-lg hover:bg-[#4080d7] transition-colors"
            >
              Ouvrir les paramètres
            </button>
          </div>
        ) : matchesForDisplay.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-500">
            <p className="text-lg">Aucun match trouvé</p>
            <p className="text-sm mt-2 text-center">pour vos équipes suivies</p>
          </div>
        ) : (
          <div>
            {/* Matchs terminés */}
            {finishedMatches.length > 0 && (
              <>
                <div className="mb-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Matchs terminés
                </div>
                <div className="space-y-3 mb-6">
                  {finishedMatches.map((match) => (
                    <MatchCard key={match.id} match={match} />
                  ))}
                </div>
              </>
            )}

            {/* Matchs à venir */}
            {upcomingMatches.length > 0 && (
              <>
                <div className="mb-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  À venir
                </div>
                <div className="space-y-3">
                  {upcomingMatches.map((match) => (
                    <MatchCard key={match.id} match={match} />
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Bottom navigation */}
      <BottomNav currentPage="home" />

      {/* Settings modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        league={league}
        followedTeams={followedTeams}
        onLeagueChange={setLeague}
        onFollowedTeamsChange={setFollowedTeams}
      />
    </div>
  );
}