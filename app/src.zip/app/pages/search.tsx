import { useState, useEffect } from "react";
import { useSearchParams } from "react-router";
import { Search } from "lucide-react";
import { MatchCard } from "../components/match-card";
import { ActiveFilters, ActiveFilter } from "../components/active-filters";
import { BottomNav } from "../components/bottom-nav";
import { FilterSheet } from "../components/filter-sheet";
import { FilterButton } from "../components/filter-button";
import { mockMatches } from "../data/mock-data";

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const [sportFilter, setSportFilter] = useState("Tous");
  const [genderFilter, setGenderFilter] = useState("Tous");
  const [teamFilters, setTeamFilters] = useState<string[]>([]);
  const [championshipFilter, setChampionshipFilter] = useState("Tous");
  const [pouleFilter, setPouleFilter] = useState("Toutes");
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [statusFilter, setStatusFilter] = useState("Tous");
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Handle URL params for pre-filled filters
  useEffect(() => {
    const teamParam = searchParams.get("team");
    const sportParam = searchParams.get("sport");
    const categoryParam = searchParams.get("category");
    const championshipParam = searchParams.get("championship");
    const pouleParam = searchParams.get("poule");

    if (teamParam && !teamFilters.includes(teamParam)) {
      setTeamFilters([teamParam]);
    }

    if (sportParam && sportParam !== "Tous") {
      setSportFilter(sportParam);
    }

    if (categoryParam && categoryParam !== "Tous") {
      const genderMap: Record<string, string> = {
        Masculin: "M",
        Féminin: "F",
        Mixte: "Mixte",
      };
      setGenderFilter(genderMap[categoryParam] || "Tous");
    }

    if (championshipParam && championshipParam !== "Tous") {
      setChampionshipFilter(championshipParam);
    }

    if (pouleParam && pouleParam !== "Toutes") {
      setPouleFilter(pouleParam);
    }
  }, [searchParams]);

  // Clear all filters
  const handleClearFilters = () => {
    setSportFilter("Tous");
    setGenderFilter("Tous");
    setTeamFilters([]);
    setChampionshipFilter("Tous");
    setPouleFilter("Toutes");
    setSelectedDate(null);
    setStatusFilter("Tous");
  };

  // Filter matches based on active filters and search
  const filteredMatches = mockMatches.filter((match) => {
    const matchesSport = sportFilter === "Tous" || match.sport === sportFilter;
    const genderMap: Record<string, string> = {
      M: "Masculin",
      F: "Féminin",
      Mixte: "Mixte",
    };
    const matchesGender =
      genderFilter === "Tous" || match.category === genderMap[genderFilter];
    const matchesTeams =
      teamFilters.length === 0 ||
      teamFilters.includes(match.teamA) ||
      teamFilters.includes(match.teamB);
    const matchesChampionship =
      championshipFilter === "Tous" || match.championship === championshipFilter;
    const matchesPoule =
      pouleFilter === "Toutes" || match.poule === pouleFilter;
    const matchesSearch =
      searchQuery === "" ||
      match.teamA.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.teamB.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.sport.toLowerCase().includes(searchQuery.toLowerCase()) ||
      match.venue.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Date filter
    let matchesDate = true;
    if (selectedDate) {
      const matchDate = new Date(match.date);
      matchesDate = matchDate.toDateString() === selectedDate.toDateString();
    }
    
    // Status filter logic - based on date only
    let matchesStatus = true;
    if (statusFilter === "Terminé") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      matchesStatus = match.date < today;
    } else if (statusFilter === "À venir") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      matchesStatus = match.date >= today;
    }

    return matchesSport && matchesGender && matchesTeams && matchesChampionship && matchesPoule && matchesSearch && matchesDate && matchesStatus;
  });

  // Sort matches by date
  const sortedMatches = [...filteredMatches].sort((a, b) => {
    return a.date.getTime() - b.date.getTime();
  });

  // Remove a specific filter
  const handleRemoveFilter = (filter: ActiveFilter) => {
    switch (filter.type) {
      case "sport":
        setSportFilter("Tous");
        break;
      case "gender":
        setGenderFilter("Tous");
        break;
      case "team":
        setTeamFilters(teamFilters.filter((t) => t !== filter.value));
        break;
      case "championship":
        setChampionshipFilter("Tous");
        break;
      case "poule":
        setPouleFilter("Toutes");
        break;
      case "date":
        setSelectedDate(null);
        break;
      case "status":
        setStatusFilter("Tous");
        break;
    }
  };

  // Get active filters for chips
  const activeFilters: ActiveFilter[] = [];
  if (sportFilter !== "Tous") {
    activeFilters.push({ type: "sport", label: sportFilter, value: sportFilter });
  }
  if (genderFilter !== "Tous") {
    activeFilters.push({ type: "gender", label: genderFilter, value: genderFilter });
  }
  teamFilters.forEach((team) => {
    activeFilters.push({ type: "team", label: team, value: team });
  });
  if (championshipFilter !== "Tous") {
    activeFilters.push({ type: "championship", label: championshipFilter, value: championshipFilter });
  }
  if (pouleFilter !== "Toutes") {
    activeFilters.push({ type: "poule", label: pouleFilter, value: pouleFilter });
  }
  if (selectedDate) {
    activeFilters.push({ 
      type: "date", 
      label: selectedDate.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' }), 
      value: selectedDate.toISOString() 
    });
  }
  if (statusFilter !== "Tous") {
    activeFilters.push({ type: "status", label: statusFilter, value: statusFilter });
  }

  // Format date for display
  const formatDate = (date: Date) => {
    const days = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
    const months = ['jan', 'fév', 'mar', 'avr', 'mai', 'juin', 'juil', 'août', 'sep', 'oct', 'nov', 'déc'];
    const dayName = days[date.getDay()];
    const day = date.getDate();
    const month = months[date.getMonth()];
    return `${dayName}. ${day} ${month}`;
  };

  const formatTime = (date: Date) => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    return `${hours}h${minutes.toString().padStart(2, '0')}`;
  };

  const getSportIcon = (sport: string) => {
    const icons: Record<string, string> = {
      Basket: "🏀",
      Volley: "🏐",
      Football: "⚽",
      Rugby: "🏉",
      Handball: "🤾",
      Tennis: "🎾",
    };
    return icons[sport] || "⚽";
  };

  const getSportColor = (sport: string) => {
    const colors: Record<string, string> = {
      Basket: "#4f8ef7",
      Volley: "#10b981",
      Football: "#f97316",
      Rugby: "#8b5cf6",
      Handball: "#ec4899",
      Tennis: "#eab308",
    };
    return colors[sport] || "#4f8ef7";
  };

  // Convert to match card format
  const matchesForDisplay = sortedMatches.map(match => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const matchDate = new Date(match.date);
    matchDate.setHours(0, 0, 0, 0);
    
    return {
      id: match.id,
      sport: match.sport,
      sportIcon: getSportIcon(match.sport),
      category: match.category,
      teamA: match.teamA,
      teamB: match.teamB,
      date: formatDate(match.date),
      time: formatTime(match.date),
      venue: match.venue,
      status: matchDate < today ? "finished" : "upcoming" as "finished" | "upcoming",
      scoreA: match.scoreA,
      scoreB: match.scoreB,
      sportColor: getSportColor(match.sport),
      championship: match.championship,
      poule: match.poule,
    };
  });

  return (
    <div className="min-h-screen bg-[#0f1117] text-white flex flex-col max-w-[390px] mx-auto">
      {/* Fixed header area */}
      <div className="flex-shrink-0">
        {/* Header */}
        <div className="px-4 pt-6 pb-4">
          <h1 className="text-2xl font-bold mb-6">Rechercher</h1>

          {/* Search bar with filter button */}
          <div className="flex items-center gap-3 mb-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Rechercher un match, une équipe..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1f2435] border border-gray-700 rounded-lg pl-11 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#4f8ef7] transition-colors"
              />
            </div>
            <div className="flex-shrink-0">
              <FilterButton
                onClick={() => setIsFilterSheetOpen(true)}
                activeCount={activeFilters.length}
              />
            </div>
          </div>

          <div className="border-b border-gray-800 pb-3">
            {/* Active filters */}
            {activeFilters.length > 0 && (
              <div className="mt-3">
                <ActiveFilters
                  filters={activeFilters}
                  onRemoveFilter={handleRemoveFilter}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Scrollable content area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 pb-24">
        {matchesForDisplay.length > 0 ? (
          <div>
            {/* Matchs terminés */}
            {matchesForDisplay.filter(m => m.status === 'finished').length > 0 && (
              <>
                <div className="mb-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Matchs terminés
                </div>
                <div className="space-y-3 mb-6">
                  {matchesForDisplay.filter(m => m.status === 'finished').map((match) => (
                    <MatchCard key={match.id} match={match} />
                  ))}
                </div>
              </>
            )}

            {/* Matchs à venir */}
            {matchesForDisplay.filter(m => m.status === 'upcoming').length > 0 && (
              <>
                <div className="mb-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  À venir
                </div>
                <div className="space-y-3">
                  {matchesForDisplay.filter(m => m.status === 'upcoming').map((match) => (
                    <MatchCard key={match.id} match={match} />
                  ))}
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-gray-500">
            <Search className="w-16 h-16 mb-4 opacity-50" />
            <p className="text-lg">Aucun match trouvé</p>
            <p className="text-sm mt-2">Essayez d'ajuster vos filtres</p>
          </div>
        )}
      </div>

      {/* Bottom navigation */}
      <BottomNav currentPage="search" />

      {/* Filter sheet */}
      <FilterSheet
        isOpen={isFilterSheetOpen}
        onClose={() => setIsFilterSheetOpen(false)}
        sportFilter={sportFilter}
        genderFilter={genderFilter}
        teamFilters={teamFilters}
        championshipFilter={championshipFilter}
        pouleFilter={pouleFilter}
        selectedDate={selectedDate}
        statusFilter={statusFilter}
        onSportChange={setSportFilter}
        onGenderChange={setGenderFilter}
        onTeamFiltersChange={setTeamFilters}
        onChampionshipChange={setChampionshipFilter}
        onPouleChange={setPouleFilter}
        onDateChange={setSelectedDate}
        onStatusChange={setStatusFilter}
        onApply={() => {}}
        onClear={handleClearFilters}
        activeCount={activeFilters.length}
      />
    </div>
  );
}