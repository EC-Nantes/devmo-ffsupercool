import { useState } from "react";
import { Settings } from "lucide-react";
import { useNavigate } from "react-router";
import { BottomNav } from "../components/bottom-nav";
import { StandingsFilterSheet } from "../components/standings-filter-sheet";
import { mockStandings, mockMatches } from "../data/mock-data";

export default function StandingsPage() {
  const navigate = useNavigate();
  const [sportFilter, setSportFilter] = useState("Tous");
  const [categoryFilter, setCategoryFilter] = useState("Tous");
  const [championshipFilter, setChampionshipFilter] = useState("District");
  const [pouleFilter, setPouleFilter] = useState("Poule 1");
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);

  const getSportColor = (sport: string) => {
    const colors: Record<string, string> = {
      Basket: "#4f8ef7",
      Volley: "#10b981",
      Football: "#f97316",
      Rugby: "#8b5cf6",
      Handball: "#ec4899",
      Tennis: "#eab308",
    };
    return colors[sport] || "#4f8ef7";
  };

  const handleClearFilters = () => {
    setSportFilter("Tous");
    setCategoryFilter("Tous");
    setChampionshipFilter("District");
    setPouleFilter("Poule 1");
  };

  const getActiveFilterCount = () => {
    // Always showing a specific championship and poule, so no active filter count
    return 0;
  };

  // Get standings for selected championship and poule
  const standings = mockStandings[championshipFilter]?.[pouleFilter] || [];

  const handleTeamClick = (teamName: string) => {
    // Find a match with this team to get sport and category info
    const matchWithTeam = mockMatches.find(
      m => m.teamA === teamName || m.teamB === teamName
    );

    const params = new URLSearchParams();
    params.set("team", teamName);

    if (matchWithTeam) {
      params.set("sport", matchWithTeam.sport);
      params.set("category", matchWithTeam.category);
    }

    if (championshipFilter !== "Tous") {
      params.set("championship", championshipFilter);
    }

    if (pouleFilter !== "Toutes") {
      params.set("poule", pouleFilter);
    }

    navigate("/search?" + params.toString());
  };

  return (
    <div className="min-h-screen bg-[#0f1117] text-white flex flex-col max-w-[390px] mx-auto">
      {/* Fixed header */}
      <div className="flex-shrink-0 px-4 pt-6 pb-4 border-b border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold">Classements</h1>
            <p className="text-sm text-gray-400 mt-1">
              {championshipFilter} · {pouleFilter}
            </p>
          </div>
          <button
            onClick={() => setIsFilterSheetOpen(true)}
            className="p-2.5 bg-[#1f2435] hover:bg-[#2a2f45] rounded-lg transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Scrollable standings table */}
      <div className="flex-1 overflow-y-auto pb-24">
        <div className="pt-4">
          {standings.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-gray-500 px-4">
              <p className="text-lg">Aucun classement disponible</p>
              <p className="text-sm mt-2">pour les filtres sélectionnés</p>
            </div>
          ) : (
            <>
              {/* Table container with horizontal scroll */}
              <div className="relative px-4 pb-2">
                {/* Fixed team name column */}
                <div className="absolute left-0 top-0 bottom-0 z-10 bg-[#0f1117]">
                  <div className="bg-[#1a1d2e] rounded-tl-lg px-3 py-2 flex items-center text-xs font-semibold text-gray-400 uppercase tracking-wider h-[34px]">
                    <div className="w-8 flex-shrink-0">#</div>
                    <div className="w-32 flex-shrink-0">Équipe</div>
                  </div>
                  <div className="bg-[#1f2435] rounded-bl-lg">
                    {standings.map((team, index) => {
                      const matchWithTeam = mockMatches.find(
                        m => m.teamA === team.team || m.teamB === team.team
                      );
                      const sportColor = matchWithTeam ? getSportColor(matchWithTeam.sport) : "#4f8ef7";

                      return (
                        <button
                          key={team.team}
                          onClick={() => handleTeamClick(team.team)}
                          className={`px-3 py-3 flex items-center text-sm w-full text-left hover:bg-[#2a2f45] transition-colors relative ${
                            index < standings.length - 1 ? "border-b border-gray-800" : ""
                          } ${
                            team.position === 1
                              ? "bg-[#4f8ef7]/10"
                              : team.position === 2
                              ? "bg-[#10b981]/10"
                              : ""
                          }`}
                        >
                          {/* Left border accent */}
                          <div
                            className="absolute left-0 top-0 bottom-0 w-1"
                            style={{ backgroundColor: sportColor }}
                          ></div>
                          <div className="w-8 flex-shrink-0 font-bold text-gray-400 pl-2">{team.position}</div>
                          <div className="w-32 flex-shrink-0 font-medium text-white truncate pr-2">{team.team}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Scrollable stats */}
                <div className="pl-[176px]">
                  <div className="overflow-x-auto scrollbar-custom">
                    <div className="inline-block min-w-full">
                      <div className="bg-[#1a1d2e] rounded-tr-lg px-3 py-2 flex items-center text-xs font-semibold text-gray-400 uppercase tracking-wider h-[34px]">
                        <div className="w-10 flex-shrink-0 text-center">J</div>
                        <div className="w-10 flex-shrink-0 text-center">V</div>
                        <div className="w-10 flex-shrink-0 text-center">N</div>
                        <div className="w-10 flex-shrink-0 text-center">D</div>
                        <div className="w-12 flex-shrink-0 text-center">BP</div>
                        <div className="w-12 flex-shrink-0 text-center">BC</div>
                        <div className="w-12 flex-shrink-0 text-center">Diff</div>
                        <div className="w-10 flex-shrink-0 text-center font-bold">Pts</div>
                      </div>
                      <div className="bg-[#1f2435] rounded-br-lg">
                        {standings.map((team, index) => (
                          <div
                            key={team.team}
                            className={`px-3 py-3 flex items-center text-sm ${
                              index < standings.length - 1 ? "border-b border-gray-800" : ""
                            } ${
                              team.position === 1
                                ? "bg-[#4f8ef7]/10"
                                : team.position === 2
                                ? "bg-[#10b981]/10"
                                : ""
                            }`}
                          >
                            <div className="w-10 flex-shrink-0 text-center text-gray-400">{team.played}</div>
                            <div className="w-10 flex-shrink-0 text-center text-green-400">{team.won}</div>
                            <div className="w-10 flex-shrink-0 text-center text-gray-400">{team.drawn}</div>
                            <div className="w-10 flex-shrink-0 text-center text-red-400">{team.lost}</div>
                            <div className="w-12 flex-shrink-0 text-center text-gray-400">{team.goalsFor}</div>
                            <div className="w-12 flex-shrink-0 text-center text-gray-400">{team.goalsAgainst}</div>
                            <div
                              className={`w-12 flex-shrink-0 text-center font-medium ${
                                team.goalDifference > 0
                                  ? "text-green-400"
                                  : team.goalDifference < 0
                                  ? "text-red-400"
                                  : "text-gray-400"
                              }`}
                            >
                              {team.goalDifference > 0 ? "+" : ""}
                              {team.goalDifference}
                            </div>
                            <div className="w-10 flex-shrink-0 text-center font-bold text-white">{team.points}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Legend */}
              <div className="mt-4 text-xs text-gray-500 space-y-1 px-4">
                <p>J = Joués, V = Victoires, N = Nuls, D = Défaites</p>
                <p>BP = Buts Pour, BC = Buts Contre, Diff = Différence, Pts = Points</p>
                <p className="text-gray-600 italic">Faites défiler horizontalement pour voir toutes les colonnes</p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Bottom navigation */}
      <BottomNav currentPage="standings" />

      {/* Filter sheet */}
      <StandingsFilterSheet
        isOpen={isFilterSheetOpen}
        onClose={() => setIsFilterSheetOpen(false)}
        sportFilter={sportFilter}
        categoryFilter={categoryFilter}
        championshipFilter={championshipFilter}
        pouleFilter={pouleFilter}
        onSportChange={setSportFilter}
        onCategoryChange={setCategoryFilter}
        onChampionshipChange={setChampionshipFilter}
        onPouleChange={setPouleFilter}
        onApply={() => {}}
        onClear={handleClearFilters}
      />
    </div>
  );
}