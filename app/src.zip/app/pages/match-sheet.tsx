import { useParams, useNavigate } from "react-router";
import { ArrowLeft, MapPin, Calendar, Users } from "lucide-react";
import { mockMatches } from "../data/mock-data";

export default function MatchSheetPage() {
  const { matchId } = useParams();
  const navigate = useNavigate();

  const match = mockMatches.find((m) => m.id === matchId);

  if (!match) {
    return (
      <div className="min-h-screen bg-[#0f1117] text-white flex items-center justify-center max-w-[390px] mx-auto">
        <div className="text-center">
          <p className="text-lg text-gray-400">Match non trouvé</p>
          <button
            onClick={() => navigate(-1)}
            className="mt-4 px-4 py-2 bg-[#4f8ef7] text-white rounded-lg hover:bg-[#4080d7] transition-colors"
          >
            Retour
          </button>
        </div>
      </div>
    );
  }

  // Check if match is finished
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const matchDate = new Date(match.date);
  matchDate.setHours(0, 0, 0, 0);
  const isFinished = matchDate < today;

  if (!isFinished) {
    return (
      <div className="min-h-screen bg-[#0f1117] text-white flex items-center justify-center max-w-[390px] mx-auto">
        <div className="text-center px-4">
          <p className="text-lg text-gray-400">Feuille de match non disponible</p>
          <p className="text-sm text-gray-500 mt-2">Ce match n'est pas encore terminé</p>
          <button
            onClick={() => navigate(-1)}
            className="mt-4 px-4 py-2 bg-[#4f8ef7] text-white rounded-lg hover:bg-[#4080d7] transition-colors"
          >
            Retour
          </button>
        </div>
      </div>
    );
  }

  const formatDate = (date: Date) => {
    const days = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    const months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    const dayName = days[date.getDay()];
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    return `${dayName} ${day} ${month} ${year}`;
  };

  const formatTime = (date: Date) => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    return `${hours}h${minutes.toString().padStart(2, '0')}`;
  };

  const getSportIcon = (sport: string) => {
    const icons: Record<string, string> = {
      Basket: "🏀",
      Volley: "🏐",
      Football: "⚽",
      Rugby: "🏉",
      Handball: "🤾",
      Tennis: "🎾",
    };
    return icons[sport] || "⚽";
  };

  const getSportColor = (sport: string) => {
    const colors: Record<string, string> = {
      Basket: "#4f8ef7",
      Volley: "#10b981",
      Football: "#f97316",
      Rugby: "#8b5cf6",
      Handball: "#ec4899",
      Tennis: "#eab308",
    };
    return colors[sport] || "#4f8ef7";
  };

  // Mock detailed match data
  const matchDetails = {
    referee: "M. Dubois",
    spectators: 156,
    quarterScores: match.sport === "Basket" ? [
      { quarter: "Q1", teamA: 18, teamB: 15 },
      { quarter: "Q2", teamA: 22, teamB: 19 },
      { quarter: "Q3", teamA: 20, teamB: 21 },
      { quarter: "Q4", teamA: 18, teamB: 17 },
    ] : match.sport === "Volley" ? [
      { quarter: "Set 1", teamA: 25, teamB: 22 },
      { quarter: "Set 2", teamA: 23, teamB: 25 },
      { quarter: "Set 3", teamA: 25, teamB: 18 },
      { quarter: "Set 4", teamA: 19, teamB: 25 },
      { quarter: "Set 5", teamA: 15, teamB: 12 },
    ] : [
      { quarter: "1ère mi-temps", teamA: Math.floor((match.scoreA || 0) * 0.45), teamB: Math.floor((match.scoreB || 0) * 0.45) },
      { quarter: "2ème mi-temps", teamA: Math.ceil((match.scoreA || 0) * 0.55), teamB: Math.ceil((match.scoreB || 0) * 0.55) },
    ],
    teamAPlayers: [
      { number: 4, name: "Martin L.", points: match.sport === "Basket" ? 18 : undefined },
      { number: 7, name: "Bernard M.", points: match.sport === "Basket" ? 15 : undefined },
      { number: 10, name: "Petit J.", points: match.sport === "Basket" ? 22 : undefined },
      { number: 12, name: "Durand S.", points: match.sport === "Basket" ? 12 : undefined },
      { number: 15, name: "Moreau P.", points: match.sport === "Basket" ? 11 : undefined },
    ],
    teamBPlayers: [
      { number: 3, name: "Leroy A.", points: match.sport === "Basket" ? 16 : undefined },
      { number: 8, name: "Simon T.", points: match.sport === "Basket" ? 14 : undefined },
      { number: 9, name: "Michel R.", points: match.sport === "Basket" ? 19 : undefined },
      { number: 11, name: "Garcia C.", points: match.sport === "Basket" ? 13 : undefined },
      { number: 14, name: "Martinez E.", points: match.sport === "Basket" ? 10 : undefined },
    ],
  };

  return (
    <div className="min-h-screen bg-[#0f1117] text-white flex flex-col max-w-[390px] mx-auto">
      {/* Header */}
      <div className="flex-shrink-0 px-4 pt-6 pb-4 border-b border-gray-800">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm">Retour</span>
        </button>
        <h1 className="text-2xl font-bold">Feuille de match</h1>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto px-4 py-4 pb-8">
        {/* Match header card */}
        <div
          className="bg-[#1f2435] border border-gray-800 rounded-xl p-4 mb-4 relative overflow-hidden"
        >
          {/* Left border accent */}
          <div
            className="absolute left-0 top-0 bottom-0 w-1"
            style={{ backgroundColor: getSportColor(match.sport) }}
          ></div>

          {/* Sport info */}
          <div className="flex items-center gap-2 text-xs text-gray-400 mb-3">
            <span>{getSportIcon(match.sport)}</span>
            <span>
              {match.sport} · {match.category}
            </span>
          </div>

          {/* Score */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex-1 text-center">
              <div className="font-semibold text-white text-lg mb-1">{match.teamA}</div>
              <div className="text-4xl font-bold" style={{ color: getSportColor(match.sport) }}>
                {match.scoreA}
              </div>
            </div>
            <div className="px-4 text-gray-500">-</div>
            <div className="flex-1 text-center">
              <div className="font-semibold text-white text-lg mb-1">{match.teamB}</div>
              <div className="text-4xl font-bold" style={{ color: getSportColor(match.sport) }}>
                {match.scoreB}
              </div>
            </div>
          </div>

          {/* Match info */}
          <div className="space-y-2 text-sm text-gray-400">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{formatDate(match.date)} à {formatTime(match.date)}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <span>{match.venue}</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>Arbitre: {matchDetails.referee}</span>
            </div>
          </div>
        </div>

        {/* Championship info */}
        <div className="bg-[#1f2435] border border-gray-800 rounded-xl p-4 mb-4">
          <div className="text-sm text-gray-400 space-y-1">
            <div className="flex justify-between">
              <span>Championnat:</span>
              <span className="text-white font-medium">{match.championship}</span>
            </div>
            <div className="flex justify-between">
              <span>Poule:</span>
              <span className="text-white font-medium">{match.poule}</span>
            </div>
            <div className="flex justify-between">
              <span>Spectateurs:</span>
              <span className="text-white font-medium">{matchDetails.spectators}</span>
            </div>
          </div>
        </div>

        {/* Score breakdown */}
        <div className="bg-[#1f2435] border border-gray-800 rounded-xl p-4 mb-4">
          <h2 className="text-lg font-semibold mb-3">Détail du score</h2>
          <div className="space-y-2">
            {matchDetails.quarterScores.map((quarter, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="w-24 text-gray-400">{quarter.quarter}</div>
                <div className="flex items-center gap-4">
                  <div className="w-12 text-right font-medium">{quarter.teamA}</div>
                  <div className="text-gray-500">-</div>
                  <div className="w-12 text-left font-medium">{quarter.teamB}</div>
                </div>
              </div>
            ))}
            <div className="border-t border-gray-700 pt-2 mt-2">
              <div className="flex items-center justify-between font-bold">
                <div className="w-24 text-gray-300">Total</div>
                <div className="flex items-center gap-4">
                  <div className="w-12 text-right" style={{ color: getSportColor(match.sport) }}>
                    {match.scoreA}
                  </div>
                  <div className="text-gray-500">-</div>
                  <div className="w-12 text-left" style={{ color: getSportColor(match.sport) }}>
                    {match.scoreB}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Team compositions */}
        <div className="space-y-4">
          {/* Team A */}
          <div className="bg-[#1f2435] border border-gray-800 rounded-xl p-4">
            <h2 className="text-lg font-semibold mb-3">{match.teamA}</h2>
            <div className="space-y-2">
              {matchDetails.teamAPlayers.map((player, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between text-sm py-2 border-b border-gray-700 last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm"
                      style={{ backgroundColor: getSportColor(match.sport) + '30', color: getSportColor(match.sport) }}
                    >
                      {player.number}
                    </div>
                    <span className="text-white">{player.name}</span>
                  </div>
                  {player.points !== undefined && (
                    <span className="text-gray-400">{player.points} pts</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Team B */}
          <div className="bg-[#1f2435] border border-gray-800 rounded-xl p-4">
            <h2 className="text-lg font-semibold mb-3">{match.teamB}</h2>
            <div className="space-y-2">
              {matchDetails.teamBPlayers.map((player, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between text-sm py-2 border-b border-gray-700 last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm"
                      style={{ backgroundColor: getSportColor(match.sport) + '30', color: getSportColor(match.sport) }}
                    >
                      {player.number}
                    </div>
                    <span className="text-white">{player.name}</span>
                  </div>
                  {player.points !== undefined && (
                    <span className="text-gray-400">{player.points} pts</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
